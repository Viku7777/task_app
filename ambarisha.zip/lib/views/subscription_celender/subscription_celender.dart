import 'package:flutter/material.dart';

class SubscriptionCelenderView extends StatelessWidget {
  const SubscriptionCelenderView({super.key});

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: false,
        elevation: 5,
        backgroundColor: Colors.white,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                border:
                    Border.all(color: const Color.fromARGB(255, 52, 150, 231))),
            child: const Center(
                child: Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
              size: 15,
            )),
          ),
        ),
        title: const Text(
          "Subscription Calender",
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            ksearch(height, width),
            ksizebox(height),
            kadditem(height, width)
          ],
        ),
      ),
    );
  }

  ksizebox(h) {
    return SizedBox(height: h * 0.01);
  }

  kadditem(h, w) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: const Color(0xff07FCFC)),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Image.asset("assets/additem.png"),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Add Items on subscription &",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontSize: 14),
                  ),
                  const Text(
                    "Save upto 10% on you’re ",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontSize: 14),
                  ),
                  const Text(
                    "dailyessentials",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontSize: 14),
                  ),
                  const SizedBox(
                    height: 3,
                  ),
                  const Text(
                    "choose from 100+ daily needs that",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w500,
                        fontSize: 12),
                  ),
                  const Text(
                    "you can subscribed to",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w500,
                        fontSize: 12),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: const Color(0xff9F43E8)),
                    child: const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "View Store",
                        style: TextStyle(color: Colors.white,fontSize: 14),
                      ),
                    ),
                  )
                ],
              )
            ]),
      ),
    );
  }

  ksearch(h, w) {
    return Container(
      height: h * 0.065,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey)),
      child: TextFormField(
          style: const TextStyle(color: Colors.black),
          decoration: const InputDecoration(
              prefixIcon: Icon(
                Icons.search,
                color: Colors.black,
              ),
              hintText: "Search Product Here",
              border: InputBorder.none)),
    );
  }
}
