import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

bool mainpayment = false;
bool showRating = false;
kbox10() {
  return SizedBox(
    height: 10.h,
  );
}

kbox5() {
  return SizedBox(
    height: 5.h,
  );
}

kbox20() {
  return SizedBox(
    height: 20.h,
  );
}

kbox30() {
  return SizedBox(
    height: 30.h,
  );
}

kbox40() {
  return SizedBox(
    height: 40.h,
  );
}

kbox50() {
  return SizedBox(
    height: 50.h,
  );
}

kbox60() {
  return SizedBox(
    height: 60.h,
  );
}

kboxw10() {
  return SizedBox(
    width: 10.h,
  );
}

kboxw20() {
  return SizedBox(
    width: 20.h,
  );
}

kboxw30() {
  return SizedBox(
    width: 30.h,
  );
}

kboxw40() {
  return SizedBox(
    width: 40.h,
  );
}

kboxw50() {
  return SizedBox(
    width: 50.h,
  );
}

kboxw60() {
  return SizedBox(
    width: 60.h,
  );
}
