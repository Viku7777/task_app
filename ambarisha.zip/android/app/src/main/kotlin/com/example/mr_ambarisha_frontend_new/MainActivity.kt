package com.example.mr_ambarisha_frontend_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
